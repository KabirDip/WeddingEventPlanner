Wedding Event Management System
=================================

This is a minimal JavaFX (Scene Builder friendly) skeleton project prepared for IntelliJ IDEA (Maven).

How to run:
1. Open this folder in IntelliJ as a Maven project.
2. Make sure JDK 17 is configured in IntelliJ.
3. Use the Maven goal: javafx:run (via Maven tool window) or run app.AppMain from IDE.
4. If JavaFX runtime errors occur, install OpenJFX SDK or use the javafx-maven-plugin (already declared).

Project structure:
- src/main/java ... java packages (app, controller, model, util, persistence)
- src/main/resources/fxml ... FXML files

This package was prepared for the user: MD.MEHEDI HASAN (ID: 2231536) - Wedding Event Management System.
