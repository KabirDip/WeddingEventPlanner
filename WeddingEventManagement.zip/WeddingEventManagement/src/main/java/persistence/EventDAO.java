package persistence;

import model.Event;

public class EventDAO {
    private FileStore<Event> store;
    public EventDAO(String path) { store = new FileStore<>(path); }
    public void save(Event e) throws Exception { store.put(e.getId(), e); }
    public Event get(String id) { return store.get(id); }
    public java.util.Collection<Event> getAll() { return store.all(); }
}
