package persistence;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class FileStore<T extends Serializable> {
    private File file;
    private Map<String, T> map = new HashMap<>();

    public FileStore(String filepath) {
        this.file = new File(filepath);
        load();
    }

    private void load() {
        if(!file.exists()) return;
        try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            Object obj = ois.readObject();
            if(obj instanceof Map) map = (Map<String, T>) obj;
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void put(String id, T obj) throws Exception {
        map.put(id, obj); persist();
    }

    public T get(String id) { return map.get(id); }
    public java.util.Collection<T> all() { return map.values(); }
    public void persist() throws Exception {
        file.getParentFile().mkdirs();
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(map);
        }
    }
}
