package persistence;

import model.User;

public class UserDAO {
    private FileStore<User> store;
    public UserDAO(String path) { store = new FileStore<>(path); }
    public void save(User u) throws Exception { store.put(u.getId(), u); }
    public User get(String id) { return store.get(id); }
    public java.util.Collection<User> getAll() { return store.all(); }
}
