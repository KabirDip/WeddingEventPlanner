package util;

import model.*;
import persistence.EventDAO;
import persistence.UserDAO;
import java.time.LocalDate;

public class SampleData {
    public static void createSample() throws Exception {
        EventDAO ed = new EventDAO("src/main/resources/data/events.dat");
        UserDAO ud = new UserDAO("src/main/resources/data/users.dat");

        Event e = new Event("EV-001", "Mehedi Wedding", LocalDate.now().plusDays(30), "Sunrise Banquet Hall");
        e.addSubEvent(new SubEvent("SE-1","Mehendi", java.time.LocalTime.of(10,0), java.time.LocalTime.of(13,0),"Mehendi Ceremony"));
        ed.save(e);

        Staff s1 = new Staff("2231536","MD.MEHEDI HASAN", model.Role.EVENT_MANAGER, "Event Manager");
        ud.save(s1);
    }
}
