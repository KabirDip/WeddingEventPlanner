package controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.SubEvent;
import util.IDGenerator;
import java.time.LocalTime;

public class TimelineController {
    @FXML private TextField txtTitle;
    @FXML private TextField txtStart;
    @FXML private TextField txtEnd;
    @FXML private TextArea txtDesc;
    @FXML private ListView<SubEvent> listSubEvents;
    @FXML private Button btnSave;

    @FXML
    public void handleAddSubEvent() {
        try {
            String id = IDGenerator.generate("SE");
            String title = txtTitle.getText();
            LocalTime start = LocalTime.parse(txtStart.getText());
            LocalTime end = LocalTime.parse(txtEnd.getText());
            SubEvent se = new SubEvent(id, title, start, end, txtDesc.getText());
            listSubEvents.getItems().add(se);
            txtTitle.clear(); txtStart.clear(); txtEnd.clear(); txtDesc.clear();
        } catch(Exception ex) {
            Alert a = new Alert(Alert.AlertType.ERROR, "Invalid time format. Use HH:mm");
            a.showAndWait();
        }
    }

    @FXML
    public void handleSave() {
        // for demo: show a confirmation
        Alert a = new Alert(Alert.AlertType.INFORMATION, "Timeline saved (demo).");
        a.showAndWait();
    }
}
