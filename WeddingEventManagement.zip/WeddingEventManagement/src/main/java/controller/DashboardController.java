package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class DashboardController {
    @FXML private Button btnTimeline;

    @FXML
    public void openTimeline(ActionEvent e) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/timeline.fxml"));
            Stage stage = (Stage) btnTimeline.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (Exception ex) { ex.printStackTrace(); }
    }
}
