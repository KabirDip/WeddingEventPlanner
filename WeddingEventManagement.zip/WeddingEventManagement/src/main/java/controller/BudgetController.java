package controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.Budget;
import model.Expense;
import util.IDGenerator;

public class BudgetController {
    @FXML private TextField txtTotal;
    @FXML private TextField txtCategory;
    @FXML private TextField txtAmount;
    @FXML private ListView<Expense> listExpenses;
    private Budget budget = new Budget();

    @FXML
    public void setTotal() {
        budget.setTotalBudget(Double.parseDouble(txtTotal.getText()));
    }

    @FXML
    public void addExpense() {
        String id = IDGenerator.generate("EX");
        Expense e = new Expense(id, txtCategory.getText(), Double.parseDouble(txtAmount.getText()));
        budget.addExpense(e);
        listExpenses.getItems().add(e);
        txtCategory.clear(); txtAmount.clear();
    }
}
