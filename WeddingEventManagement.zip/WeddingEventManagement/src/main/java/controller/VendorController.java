package controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.Vendor;
import util.IDGenerator;

public class VendorController {
    @FXML private TextField txtName;
    @FXML private TextField txtService;
    @FXML private ListView<Vendor> listVendors;

    @FXML
    public void addVendor() {
        String id = IDGenerator.generate("VD");
        Vendor v = new Vendor(id, txtName.getText(), txtService.getText());
        listVendors.getItems().add(v);
        txtName.clear(); txtService.clear();
    }
}
