package controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.Task;
import util.IDGenerator;
import java.time.LocalDate;

public class TaskController {
    @FXML private TextField txtTitle;
    @FXML private DatePicker dpDue;
    @FXML private ChoiceBox<String> choicePriority;
    @FXML private ListView<Task> listTasks;

    @FXML
    public void initialize() {
        choicePriority.getItems().addAll("LOW","MEDIUM","HIGH");
    }

    @FXML
    public void addTask() {
        String id = IDGenerator.generate("TK");
        Task t = new Task(id, txtTitle.getText());
        t.setDueDate(dpDue.getValue());
        t.setPriority(Task.Priority.valueOf(choicePriority.getValue()));
        listTasks.getItems().add(t);
        txtTitle.clear(); dpDue.setValue(null); choicePriority.setValue(null);
    }
}
