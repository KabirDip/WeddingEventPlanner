package model;

import java.io.Serializable;

public class Guest implements Serializable {
    public enum RSVP { UNKNOWN, ACCEPTED, DECLINED }
    private String id;
    private String name;
    private String contact;
    private RSVP rsvp;
    private String relation;

    public Guest(String id, String name, String contact) {
        this.id = id; this.name = name; this.contact = contact; this.rsvp = RSVP.UNKNOWN;
    }

    public String getId(){return id;}
    public String getName(){return name;}
    public String getContact(){return contact;}
    public RSVP getRsvp(){return rsvp;}
    public void setRsvp(RSVP rsvp){this.rsvp = rsvp;}
}
