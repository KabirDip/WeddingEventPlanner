package model;

import java.io.Serializable;
import java.time.LocalDate;

public class Media implements Serializable {
    private String id;
    private String filename;
    private String uploadedByUserId;
    private LocalDate uploadDate;
    private String path;

    public Media(String id, String filename, String uploadedByUserId, String path) {
        this.id = id; this.filename = filename; this.uploadedByUserId = uploadedByUserId;
        this.path = path; this.uploadDate = LocalDate.now();
    }

    public String getId(){return id;}
    public String getFilename(){return filename;}
    public String getUploadedByUserId(){return uploadedByUserId;}
    public String getPath(){return path;}
}
