package model;

import java.io.Serializable;
import java.time.LocalTime;

public class SubEvent implements Serializable {
    private String id;
    private String title;
    private LocalTime start;
    private LocalTime end;
    private String description;

    public SubEvent(String id, String title, LocalTime start, LocalTime end, String desc) {
        this.id = id;
        this.title = title;
        this.start = start;
        this.end = end;
        this.description = desc;
    }

    public String getId(){return id;}
    public String getTitle(){return title;}
    public LocalTime getStart(){return start;}
    public LocalTime getEnd(){return end;}
    public String getDescription(){return description;}
    public String toString(){ return title + " (" + start + " - " + end + ")"; }
}
