package model;

import java.io.Serializable;
import java.time.LocalDate;

public class Task implements Serializable {
    public enum Status { PENDING, IN_PROGRESS, DONE }
    public enum Priority { LOW, MEDIUM, HIGH }

    private String id;
    private String title;
    private String assignedToUserId;
    private LocalDate dueDate;
    private Priority priority;
    private Status status;

    public Task(String id, String title) {
        this.id = id;
        this.title = title;
        this.status = Status.PENDING;
        this.priority = Priority.MEDIUM;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getAssignedToUserId() { return assignedToUserId; }
    public void setAssignedToUserId(String assignedToUserId) { this.assignedToUserId = assignedToUserId; }
    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    public Priority getPriority() { return priority; }
    public void setPriority(Priority priority) { this.priority = priority; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
}
