package model;

public class Staff extends User {
    private String designation;

    public Staff(String id, String name, Role role, String designation) {
        super(id, name, role);
        this.designation = designation;
    }

    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }
}
