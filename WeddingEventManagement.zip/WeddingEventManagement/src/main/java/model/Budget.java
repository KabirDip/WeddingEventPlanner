package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Budget implements Serializable {
    private double totalBudget;
    private List<Expense> expenses = new ArrayList<>();

    public void setTotalBudget(double total) { this.totalBudget = total; }
    public double getTotalBudget() { return totalBudget; }
    public void addExpense(Expense e) { expenses.add(e); }
    public double getTotalExpenses() { return expenses.stream().mapToDouble(Expense::getAmount).sum(); }
    public List<Expense> getExpenses() { return expenses; }
}
