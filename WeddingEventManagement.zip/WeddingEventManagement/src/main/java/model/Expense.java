package model;

import java.io.Serializable;
import java.time.LocalDate;

public class Expense implements Serializable {
    private String id;
    private String category;
    private double amount;
    private LocalDate date;

    public Expense(String id, String category, double amount) {
        this.id = id; this.category = category; this.amount = amount; this.date = LocalDate.now();
    }

    public String getId(){return id;}
    public String getCategory(){return category;}
    public double getAmount(){return amount;}
    public LocalDate getDate(){return date;}
}
