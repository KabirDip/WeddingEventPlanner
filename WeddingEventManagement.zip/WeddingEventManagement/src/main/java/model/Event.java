package model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Event implements Serializable {
    private String id;
    private String name;
    private LocalDate date;
    private String venue;
    private List<SubEvent> subEvents = new ArrayList<>();

    public Event(String id, String name, LocalDate date, String venue) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.venue = venue;
    }

    public void addSubEvent(SubEvent se) { subEvents.add(se); }
    public String getId() { return id; }
    public String getName() { return name; }
    public LocalDate getDate() { return date; }
    public String getVenue() { return venue; }
    public List<SubEvent> getSubEvents() { return subEvents; }
}
