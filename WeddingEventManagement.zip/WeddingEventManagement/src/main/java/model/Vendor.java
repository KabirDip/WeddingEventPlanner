package model;

import java.io.Serializable;
import java.time.LocalDate;

public class Vendor implements Serializable {
    private String id;
    private String name;
    private String serviceType;
    private String contact;
    private String contractFilePath;
    private LocalDate contractStart, contractEnd;

    public Vendor(String id, String name, String serviceType) {
        this.id = id; this.name = name; this.serviceType = serviceType;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getServiceType() { return serviceType; }
    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }
    public String getContractFilePath() { return contractFilePath; }
    public void setContractFilePath(String contractFilePath) { this.contractFilePath = contractFilePath; }
    public LocalDate getContractStart() { return contractStart; }
    public void setContractStart(LocalDate contractStart) { this.contractStart = contractStart; }
    public LocalDate getContractEnd() { return contractEnd; }
    public void setContractEnd(LocalDate contractEnd) { this.contractEnd = contractEnd; }
}
